## How to compile the Python module?
Run ```python compile_cpp.py build```
