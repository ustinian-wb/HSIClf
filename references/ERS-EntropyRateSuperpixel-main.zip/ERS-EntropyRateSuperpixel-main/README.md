# ERS-EntropyRateSuperpixel
great work from :  
https://github.com/mingyuliutw/EntropyRateSuperpixel  
and  
https://github.com/wctu/SEAL  

If you got the error about "ImportError: DLL load failed: The specified module could not be found.".  
Then you are at the right place. :)  
The reason is the python version!    
# How to rebuild the model  
make it can be use in Python3  
go to folder ERS_Python  
run command

    python compile_cpp.py build  

and then you can get the .pyd   

Have fun !  

# Run demo 
    python demoERS.py  
